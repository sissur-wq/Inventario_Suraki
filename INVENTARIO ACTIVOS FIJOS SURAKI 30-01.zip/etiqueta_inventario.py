import pandas as pd
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
import os

# --- CONFIGURACIÓN ---
ARCHIVO_EXCEL = "INVENTARIO ACTIVOS FIJOS SURAKI 30-01.xlsx"
ARCHIVO_SALIDA = "Etiquetas_Suraki_FullDatos_57x32.pdf"

# --- DIMENSIONES 57x32 mm ---
ANCHO = 57 * mm
ALTO = 32 * mm

# Colores
COLOR_AZUL = colors.HexColor("#003366")
COLOR_ROJO = colors.firebrick

def detectar_encabezados(df_raw):
    """Busca fila de encabezados en las primeras 15 filas"""
    keywords = ['DESCRIPCION', 'DESCRIPCIÓN', 'MARCA', 'MODELO', 'SERIAL', 'CÓDIGO', 'CODIGO']
    for i, row in df_raw.iterrows():
        fila_str = " ".join([str(val).upper() for val in row.values])
        matches = sum(1 for word in keywords if word in fila_str)
        if matches >= 2: return i
    return None

def buscar_columna(df, posibles_nombres):
    cols_limpias = [str(c).strip().upper() for c in df.columns]
    for candidato in posibles_nombres:
        cand = candidato.upper()
        if cand in cols_limpias: return df.columns[cols_limpias.index(cand)]
        for i, col_real in enumerate(cols_limpias):
            if cand in col_real: return df.columns[i]
    return None

def dibujar_texto_dinamico(c, texto, x, y, max_ancho, font_name="Helvetica", max_font_size=8, min_font_size=4):
    """Reduce la fuente hasta que el texto quepa en el ancho disponible"""
    size = max_font_size
    c.setFont(font_name, size)
    while c.stringWidth(texto, font_name, size) > max_ancho and size > min_font_size:
        size -= 0.5
        c.setFont(font_name, size)
    c.drawString(x, y, texto)
    return size # Devuelve el tamaño usado por si necesitamos calcular espaciado

def generar_pdf_full():
    if not os.path.exists(ARCHIVO_EXCEL):
        print(f"❌ ERROR: No encuentro '{ARCHIVO_EXCEL}'")
        return

    print(f"📂 Generando etiquetas 'Full Datos' (57x32mm)...")
    try:
        xls = pd.ExcelFile(ARCHIVO_EXCEL)
    except Exception as e:
        print(f"❌ Error abriendo Excel: {e}")
        return

    c = canvas.Canvas(ARCHIVO_SALIDA, pagesize=(ANCHO, ALTO))
    total_etiquetas = 0

    for nombre_hoja in xls.sheet_names:
        print(f"   Analizando: {nombre_hoja}...")
        try:
            df_temp = pd.read_excel(xls, sheet_name=nombre_hoja, header=None, nrows=15)
            fila_header = detectar_encabezados(df_temp)
            if fila_header is None: continue

            df = pd.read_excel(xls, sheet_name=nombre_hoja, header=fila_header)
            
            col_id = buscar_columna(df, ['CODIGO', 'CÓDIGO', 'ETIQUETA', 'ID'])
            col_desc = buscar_columna(df, ['DESCRIPCION', 'DESCRIPCIÓN', 'NOMBRE', 'BIEN'])
            col_marca = buscar_columna(df, ['MARCA', 'FABRICANTE'])
            col_modelo = buscar_columna(df, ['MODELO', 'REF'])
            col_serial = buscar_columna(df, ['SERIAL', 'SERIE', 'S/N'])

            if not col_id or not col_desc: continue

            for index, row in df.iterrows():
                id_val = str(row[col_id]).strip()
                if id_val.lower() in ['nan', 'nat', 'none', '', '0']: continue
                
                total_etiquetas += 1

                # 1. ENCABEZADO (Aprovechamos borde superior)
                c.setFillColor(COLOR_AZUL)
                c.rect(0, ALTO - 6*mm, ANCHO, 6*mm, fill=1, stroke=0)
                
                c.setFillColor(colors.white)
                c.setFont("Helvetica-Bold", 8)
                c.drawString(2*mm, ALTO - 4.5*mm, "HIPER SURAKI")
                
                # Nombre Sede (Pequeño)
                c.setFont("Helvetica", 5)
                c.drawRightString(ANCHO - 2*mm, ALTO - 4.5*mm, nombre_hoja[:18])

                # --- ZONA DE DATOS (Izquierda) Ancho disponible: 36mm ---
                c.setFillColor(colors.black)
                
                # DESCRIPCIÓN (Prioridad visual)
                desc = str(row[col_desc]).replace('\n', ' ').strip()
                
                # Lógica simple de dos líneas para descripción
                c.setFont("Helvetica", 7)
                palabras = desc.split()
                linea1 = ""
                linea2 = ""
                
                for palabra in palabras:
                    if c.stringWidth(linea1 + " " + palabra, "Helvetica", 7) < 36*mm:
                        linea1 += " " + palabra
                    else:
                        linea2 += " " + palabra
                
                # Dibujamos descripción
                cursor_y = ALTO - 10*mm
                c.drawString(2*mm, cursor_y, linea1.strip())
                if linea2:
                    cursor_y -= 3*mm # Bajamos para la linea 2
                    c.drawString(2*mm, cursor_y, linea2.strip())

                # MARCA / MODELO (Debajo de la descripción)
                cursor_y -= 4*mm
                marca = str(row[col_marca]) if col_marca and str(row[col_marca]).lower() != 'nan' else ""
                modelo = str(row[col_modelo]) if col_modelo and str(row[col_modelo]).lower() != 'nan' else ""
                txt_mod = f"{marca} / {modelo}".strip(" / ")
                if not txt_mod: txt_mod = "GENÉRICO"
                
                # Usamos fuente dinámica para que no se corte la marca
                dibujar_texto_dinamico(c, txt_mod, 2*mm, cursor_y, 35*mm, "Helvetica-Bold", 7)
                
                # SERIAL (Al fondo a la izquierda)
                if col_serial:
                    ser = str(row[col_serial])
                    if ser.lower() not in ['nan', '']:
                        cursor_y -= 3.5*mm
                        c.setFillColor(colors.black)
                        dibujar_texto_dinamico(c, f"SN: {ser}", 2*mm, cursor_y, 35*mm, "Courier", 7)

                # --- CÓDIGO QR Y ID (Zona Derecha) ---
                # Contenido del QR: Texto plano con todos los datos
                qr_content = f"ID:{id_val}\nBien:{desc[:20]}\nMarca:{marca}\nSN:{ser if col_serial else 'N/A'}"
                
                # QR Gráfico
                qr_size = 16 * mm
                qr_obj = qr.QrCodeWidget(qr_content)
                qr_obj.barWidth = qr_size
                qr_obj.barHeight = qr_size
                qr_obj.qrVersion = 1 # Autoajuste
                
                d = Drawing(qr_size, qr_size)
                d.add(qr_obj)
                # Posición: Pegado a la derecha
                qr_x = ANCHO - 19*mm
                qr_y = 6*mm
                d.drawOn(c, qr_x, qr_y)

                # ID ROJO (COMPLETO)
                # Centrado debajo del QR
                c.setFillColor(COLOR_ROJO)
                # Calculamos el centro exacto del área del QR para el texto
                center_x_qr = qr_x + (qr_size / 2)
                
                # Usamos una función especial para centrar y reducir tamaño si es largo
                texto_id = id_val
                font_id = "Helvetica-Bold"
                size_id = 8
                
                c.setFont(font_id, size_id)
                # Reducimos tamaño si el ID es más ancho que el propio QR (17mm margen)
                while c.stringWidth(texto_id, font_id, size_id) > 18*mm and size_id > 4:
                    size_id -= 0.5
                    c.setFont(font_id, size_id)
                
                c.drawCentredString(center_x_qr, 2.5*mm, texto_id)

                c.showPage()

        except Exception as e:
            print(f"⚠️ Error en hoja {nombre_hoja}: {e}")
            continue

    c.save()
    print(f"\n✅ ¡LISTO! {total_etiquetas} etiquetas generadas en: {ARCHIVO_SALIDA}")

if __name__ == "__main__":
    generar_pdf_full()