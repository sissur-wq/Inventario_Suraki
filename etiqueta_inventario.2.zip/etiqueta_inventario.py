import pandas as pd
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
import os

# --- CRITICAL CONFIGURATION ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_EXCEL = os.path.join(BASE_DIR, "INVENTARIO ACTIVOS FIJOS SURAKI 30-01.xlsx")
ARCHIVO_SALIDA = os.path.join(BASE_DIR, "Etiquetas_Suraki_Final.pdf")

# PLACEHOLDER FOR LOGO - User should replace this or place 'logo_suraki.png'
# If file is missing, script will skip logo but warn.
ARCHIVO_LOGO = os.path.join(BASE_DIR, "logo_suraki.png") 

# --- DIMENSIONES 57x32 mm ---
ANCHO = 57 * mm
ALTO = 32 * mm

# Colores y Fuentes
COLOR_NEGRO = colors.black
FONT_BOLD = "Helvetica-Bold"
FONT_REGULAR = "Helvetica"
FONT_MONO = "Courier"

def cargar_nomenclatura(xls):
    """
    Carga la hoja de 'Codificación de Activos' para mapear prefijos a nombres de categoría.
    Retorna un diccionario {CODIGO: NOMBRE_CATEGORIA}.
    """
    mapa_categorias = {}
    try:
        # Buscar hoja que contenga "codif" o "nomenclatura" (case insensitive)
        hoja_nom = next((s for s in xls.sheet_names if "codif" in s.lower() or "nomenclatura" in s.lower() or "activos" in s.lower()), None)
        
        if hoja_nom:
            print(f"   Cargando nomenclatura desde: {hoja_nom}")
            # Asumimos que la fila 2 tiene encabezados o datos directos. 
            # Leemos sin header primero para inspeccionar estructura o con header=1 (fila 2 es 0-indexed 1)
            # En el analisis previo: Row 2 = Header, Row 3 = Data
            # Header: 'Cdigo (XX)', 'Categora'
            df_nom = pd.read_excel(xls, sheet_name=hoja_nom, header=1) 
            
            # Normalizamos nombres de columnas para encontrar 'Codigo' y 'Categoria'
            col_cod = next((c for c in df_nom.columns if "diga" in str(c).lower() or "digo" in str(c).lower() or "XX" in str(c)), None)
            col_cat = next((c for c in df_nom.columns if "cat" in str(c).lower()), None)
            
            if col_cod and col_cat:
                for index, row in df_nom.iterrows():
                    codigo = str(row[col_cod]).strip().upper()
                    categoria = str(row[col_cat]).strip()
                    if codigo and codigo != 'NAN':
                        mapa_categorias[codigo] = categoria
            else:
                print(f"   No se detectaron columnas 'Código' y 'Categoría'. Columnas leídas: {list(df_nom.columns)}")
        else:
            print("   No se encontró hoja de Nomenclatura.")
            
    except Exception as e:
        print(f"   Error cargando nomenclatura: {e}")
        
    return mapa_categorias

def obtener_nombre_categoria(id_val, mapa_categorias):
    """
    Intenta obtener el nombre de la categoría basándose en partes del ID.
    Ej: 'RE-01...' -> Busca 'RE' en el mapa.
    """
    if not mapa_categorias: return ""
    
    partes = id_val.replace('-', ' ').replace('_', ' ').split()
    for parte in partes:
        p_clean = parte.strip().upper()
        if p_clean in mapa_categorias:
            return mapa_categorias[p_clean]
    return ""

def dibujar_texto_dinamico(c, texto, x, y, max_ancho, font_name="Helvetica", max_font_size=8, min_font_size=4):
    """Reduce la fuente hasta que el texto quepa en el ancho disponible"""
    size = max_font_size
    c.setFont(font_name, size)
    while c.stringWidth(texto, font_name, size) > max_ancho and size > min_font_size:
        size -= 0.5
        c.setFont(font_name, size)
    c.drawString(x, y, texto)
    return size

def detectar_encabezados(df_raw):
    """Busca fila de encabezados en las primeras 15 filas"""
    keywords = ['DESCRIPCION', 'DESCRIPCIÓN', 'MARCA', 'MODELO', 'SERIAL', 'CÓDIGO', 'CODIGO']
    for i, row in df_raw.iterrows():
        fila_str = " ".join([str(val).upper() for val in row.values])
        matches = sum(1 for word in keywords if word in fila_str)
        if matches >= 2: return i
    return None

def buscar_columna(df, posibles_nombres):
    cols_limpias = [str(c).strip().upper() for c in df.columns]
    for candidato in posibles_nombres:
        cand = candidato.upper()
        if cand in cols_limpias: return df.columns[cols_limpias.index(cand)]
        for i, col_real in enumerate(cols_limpias):
            if cand in col_real: return df.columns[i]
    return None

def generar_pdf_final():
    if not os.path.exists(ARCHIVO_EXCEL):
        print(f"❌ ERROR: No encuentro '{ARCHIVO_EXCEL}'")
        return

    print(f"Generando etiquetas 'Estilo Final' (57x32mm)...")
    try:
        xls = pd.ExcelFile(ARCHIVO_EXCEL)
        mapa_nomenclatura = cargar_nomenclatura(xls)
    except Exception as e:
        print(f"Error abriendo Excel: {e}")
        return

    c = canvas.Canvas(ARCHIVO_SALIDA, pagesize=(ANCHO, ALTO))
    total_etiquetas = 0

    # Determinar si existe logo
    tiene_logo = os.path.exists(ARCHIVO_LOGO)
    if not tiene_logo:
        print(f"AVISO: No se encontró '{ARCHIVO_LOGO}'. Se dejará el espacio o se usará texto alternativo.")

    for nombre_hoja in xls.sheet_names:
        # Ignorar hojas de nomenclatura/configuracion
        if "codifi" in nombre_hoja.lower() or "modelo" in nombre_hoja.lower() or "nomenclatura" in nombre_hoja.lower() or "activos" in nombre_hoja.lower(): continue

        print(f"   Analizando: {nombre_hoja}...")
        try:
            df_temp = pd.read_excel(xls, sheet_name=nombre_hoja, header=None, nrows=15)
            fila_header = detectar_encabezados(df_temp)
            if fila_header is None: continue

            df = pd.read_excel(xls, sheet_name=nombre_hoja, header=fila_header)
            
            col_id = buscar_columna(df, ['CODIGO', 'CÓDIGO', 'ETIQUETA', 'ID'])
            col_desc = buscar_columna(df, ['DESCRIPCION', 'DESCRIPCIÓN', 'NOMBRE', 'BIEN'])
            col_marca = buscar_columna(df, ['MARCA', 'FABRICANTE'])
            col_modelo = buscar_columna(df, ['MODELO', 'REF'])
            col_serial = buscar_columna(df, ['SERIAL', 'SERIE', 'S/N'])

            if not col_id or not col_desc: continue

            for index, row in df.iterrows():
                id_val = str(row[col_id]).strip()
                if id_val.lower() in ['nan', 'nat', 'none', '', '0']: continue
                
                total_etiquetas += 1

                # --- 1. CABECERA (LOGO + TITULO) ---
                cursor_y = ALTO - 2*mm # Margen superior
                
                # Logo
                logo_width = 12*mm # Arox 12mm ancho
                logo_height = 10*mm # Aprox 10mm alto
                logo_x = 2*mm
                logo_y = ALTO - logo_height - 1*mm # Top-align

                if tiene_logo:
                    try:
                        c.drawImage(ARCHIVO_LOGO, logo_x, logo_y, width=logo_width, height=logo_height, mask='auto', preserveAspectRatio=True)
                    except:
                        c.rect(logo_x, logo_y, logo_width, logo_height) # Placeholder box
                
                # Título "HIPER SURAKI"
                # Alineado a la derecha del logo, centrado verticalmente respecto al logo
                c.setFillColor(COLOR_NEGRO)
                c.setFont(FONT_BOLD, 10) # Tamaño visible
                title_x = logo_x + logo_width + 2*mm
                title_y = logo_y + (logo_height / 2) - 1.5*mm # Ajuste visual
                c.drawString(title_x, title_y, "HIPER SURAKI")

                # --- 2. INFORMACIÓN DEL PRODUCTO (Izquierda) ---
                # Debajo del logo. Ancho disponible hasta el QR
                content_x = 2*mm
                content_y_start = logo_y - 2*mm # Empezamos debajo del logo
                content_width = 38*mm # Dejamos espacio para el QR a la derecha

                # Categoría (desde Nomenclatura) - Opcional, en pequeño
                desc_categoria = obtener_nombre_categoria(id_val, mapa_nomenclatura)
                if desc_categoria:
                    c.setFillColor(colors.darkgrey)
                    dibujar_texto_dinamico(c, desc_categoria, content_x, content_y_start, content_width, FONT_REGULAR, 5, 4)
                    content_y_start -= 2.5*mm # Bajamos cursor

                # Descripción (Principal)
                desc = str(row[col_desc]).replace('\n', ' ').strip()
                c.setFillColor(COLOR_NEGRO)
                
                # Multi-line logic simple
                c.setFont(FONT_REGULAR, 7.5) # Un poco mas grande como en la foto
                palabras = desc.split()
                linea1 = ""
                linea2 = ""
                linea3 = "" # Max 3 lineas
                
                cursor_texto = content_y_start

                for palabra in palabras:
                    if c.stringWidth(linea1 + " " + palabra, FONT_REGULAR, 7.5) < content_width:
                        linea1 += " " + palabra
                    elif c.stringWidth(linea2 + " " + palabra, FONT_REGULAR, 7.5) < content_width:
                        linea2 += " " + palabra
                    else:
                        linea3 += " " + palabra

                c.drawString(content_x, cursor_texto, linea1.strip())
                if linea2:
                    cursor_texto -= 3*mm
                    c.drawString(content_x, cursor_texto, linea2.strip())
                if linea3:
                    cursor_texto -= 3*mm
                    c.drawString(content_x, cursor_texto, linea3.strip())

                # Marca / Modelo / Serial
                cursor_texto -= 4*mm
                marca = str(row[col_marca]) if col_marca and str(row[col_marca]).lower() != 'nan' else ""
                modelo = str(row[col_modelo]) if col_modelo and str(row[col_modelo]).lower() != 'nan' else ""
                
                txt_detalle = f"{marca} / {modelo}".strip(" / ")
                if not txt_detalle: txt_detalle = "GENÉRICO"
                
                c.setFont(FONT_BOLD, 7) # Negrita para marca/modelo
                dibujar_texto_dinamico(c, txt_detalle, content_x, cursor_texto, content_width, FONT_BOLD, 7, 5)

                # Serial (opcional, si cabe)
                if col_serial:
                    ser = str(row[col_serial])
                    if ser.lower() not in ['nan', '']:
                         cursor_texto -= 3*mm
                         c.setFont(FONT_REGULAR, 6)
                         c.drawString(content_x, cursor_texto, f"SN: {ser}")


                # --- 3. CODIGO QR Y ID (Derecha) ---
                qr_size = 17 * mm
                qr_x = ANCHO - 18*mm - 1*mm # Margen derecho 1mm
                qr_y = ALTO - 20*mm # Posición vertical
                
                # El marco del QR (La foto muestra un borde)
                c.setLineWidth(0.5)
                c.setStrokeColor(colors.lightgrey) # Gris o Azul muy claro
                # Rectangulo borde
                c.rect(qr_x - 0.5*mm, qr_y - 0.5*mm, qr_size + 1*mm, qr_size + 1*mm, stroke=1, fill=0)

                # QR
                qr_content = f"ID:{id_val}\nBien:{desc[:20]}\nMarca:{marca}\n{desc_categoria}"
                qr_obj = qr.QrCodeWidget(qr_content)
                qr_obj.barWidth = qr_size
                qr_obj.barHeight = qr_size
                qr_obj.qrVersion = 1
                
                d = Drawing(qr_size, qr_size)
                d.add(qr_obj)
                d.drawOn(c, qr_x, qr_y)

                # ID DEBAJO DEL QR
                c.setFillColor(COLOR_NEGRO) # Negro como en la foto
                center_x_qr = qr_x + (qr_size / 2)
                y_id = qr_y - 3*mm # 3mm debajo del QR
                
                c.setFont(FONT_BOLD, 8)
                # Auto-scaling para ID largo
                size_id = 8
                while c.stringWidth(id_val, FONT_BOLD, size_id) > (qr_size + 4*mm) and size_id > 4:
                    size_id -= 0.5
                    c.setFont(FONT_BOLD, size_id)
                
                c.drawCentredString(center_x_qr, y_id, id_val)

                c.showPage()

        except Exception as e:
            print(f"Error en hoja {nombre_hoja}: {e}")
            continue

    c.save()
    print(f"\nLISTO! {total_etiquetas} etiquetas generadas en: {ARCHIVO_SALIDA}")
    if not tiene_logo:
        print(f"SUGERENCIA: Coloca una imagen llamada 'logo_suraki.png' en la carpeta para ver el logo real.")

if __name__ == "__main__":
    generar_pdf_final()