import pandas as pd
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
import os

# --- CONFIGURACIÓN ---
ARCHIVO_EXCEL = "INVENTARIO ACTIVOS FIJOS SURAKI 30-01.xlsx"
# Ajusta el nombre de la hoja si es necesario (ej: "Base Datos Maestra Hiper Suraki")
HOJA_NOMBRE = "Base Datos Maestra Hiper Suraki" 
ARCHIVO_SALIDA = "Etiquetas_Suraki_Final.pdf"

# Dimensiones y Colores
ANCHO = 100 * mm
ALTO = 50 * mm
COLOR_AZUL = colors.HexColor("#003366")
COLOR_ROJO = colors.firebrick

def detectar_encabezados(df_raw):
    """Busca en qué fila están los títulos de las columnas"""
    print("🔎 Buscando fila de encabezados...")
    # Palabras clave para identificar la fila correcta
    keywords = ['DESCRIPCION', 'DESCRIPCIÓN', 'MARCA', 'MODELO', 'SERIAL', 'CÓDIGO', 'CODIGO']
    
    for i, row in df_raw.iterrows():
        # Convertimos la fila a texto y mayúsculas para comparar
        fila_str = " ".join([str(val).upper() for val in row.values])
        
        # Si la fila contiene al menos 2 palabras clave, es la fila de encabezados
        matches = sum(1 for word in keywords if word in fila_str)
        if matches >= 2:
            print(f"✅ Encabezados encontrados en la fila {i}")
            return i
            
    print("⚠️ No se detectó automáticamente. Usando fila 0 por defecto.")
    return 0

def limpiar_nombre_columna(col):
    return str(col).strip().upper()

def buscar_columna(df, posibles_nombres):
    """Encuentra el nombre exacto de la columna en el Excel"""
    cols_excel = [limpiar_nombre_columna(c) for c in df.columns]
    
    for candidato in posibles_nombres:
        candidato = candidato.upper()
        # 1. Búsqueda exacta
        if candidato in cols_excel:
            return df.columns[cols_excel.index(candidato)]
        
        # 2. Búsqueda parcial (ej: 'CODIGO' en 'CODIGO DE BIEN')
        for i, col_real in enumerate(cols_excel):
            if candidato in col_real:
                return df.columns[i]
    return None

def generar_pdf():
    if not os.path.exists(ARCHIVO_EXCEL):
        print(f"❌ ERROR: No encuentro el archivo '{ARCHIVO_EXCEL}'")
        return

    try:
        # 1. Leer primeras filas para detectar dónde empieza la tabla
        df_temp = pd.read_excel(ARCHIVO_EXCEL, sheet_name=HOJA_NOMBRE, header=None, nrows=10)
        fila_header = detectar_encabezados(df_temp)
        
        # 2. Cargar el Excel desde la fila correcta
        df = pd.read_excel(ARCHIVO_EXCEL, sheet_name=HOJA_NOMBRE, header=fila_header)
    except Exception as e:
        print(f"❌ Error leyendo Excel: {e}")
        return

    # 3. Identificar columnas automáticamente
    print("⚙️ Analizando columnas...")
    col_id = buscar_columna(df, ['CODIGO', 'CÓDIGO', 'ETIQUETA', 'ID', 'PLACA'])
    col_desc = buscar_columna(df, ['DESCRIPCION', 'DESCRIPCIÓN', 'NOMBRE', 'BIEN'])
    col_marca = buscar_columna(df, ['MARCA', 'FABRICANTE'])
    col_modelo = buscar_columna(df, ['MODELO', 'REF'])
    col_serial = buscar_columna(df, ['SERIAL', 'SERIE', 'S/N'])

    if not col_id or not col_desc:
        print("❌ ERROR CRÍTICO: No pude identificar las columnas 'CÓDIGO' o 'DESCRIPCIÓN'.")
        print(f"   Columnas leídas: {list(df.columns)}")
        return

    print(f"   -> ID: {col_id}")
    print(f"   -> Desc: {col_desc}")

    # 4. Generar PDF
    c = canvas.Canvas(ARCHIVO_SALIDA, pagesize=(ANCHO, ALTO))
    contador = 0
    
    print("🖨️ Generando etiquetas...")
    for index, row in df.iterrows():
        # Validar que tenga ID
        id_val = str(row[col_id]).strip()
        if id_val.lower() in ['nan', 'nat', 'none', '']: continue
        
        contador += 1
        
        # --- DISEÑO ---
        # Encabezado Azul
        c.setFillColor(COLOR_AZUL)
        c.rect(0, ALTO - 12*mm, ANCHO, 12*mm, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 14)
        c.drawString(5*mm, ALTO - 9*mm, "HIPER SURAKI")

        # Descripción
        c.setFillColor(colors.black)
        c.setFont("Helvetica", 10)
        desc = str(row[col_desc]).replace('\n', ' ')
        if len(desc) > 35: desc = desc[:32] + "..."
        c.drawString(5*mm, ALTO - 20*mm, desc)
        
        # Marca / Modelo
        marca = str(row[col_marca]) if col_marca and str(row[col_marca]).lower() != 'nan' else ""
        modelo = str(row[col_modelo]) if col_modelo and str(row[col_modelo]).lower() != 'nan' else ""
        texto_mod = f"{marca} / {modelo}".strip(" / ")
        if not texto_mod: texto_mod = "GENÉRICO"
        
        c.setFont("Helvetica-Bold", 10)
        c.setFillColor(colors.darkgrey)
        c.drawString(5*mm, ALTO - 26*mm, texto_mod)
        
        # Serial
        if col_serial:
            ser = str(row[col_serial])
            if ser.lower() != 'nan':
                c.setFont("Courier", 9)
                c.setFillColor(colors.black)
                c.drawString(5*mm, ALTO - 38*mm, f"SN: {ser}")

        # QR
        qr_data = f"https://tusistema.com/activo/{id_val}"
        qr_code = qr.QrCodeWidget(qr_data)
        qr_code.barWidth = 28 * mm
        qr_code.barHeight = 28 * mm
        qr_code.qrVersion = 1
        d = Drawing(28*mm, 28*mm)
        d.add(qr_code)
        d.drawOn(c, ANCHO - 35*mm, 10*mm)

        # ID Rojo
        c.setFillColor(COLOR_ROJO)
        c.setFont("Helvetica-Bold", 10)
        c.drawCentredString(ANCHO - 21*mm, 5*mm, id_val)

        c.showPage()

    c.save()
    print(f"\n✅ ¡LISTO! {contador} etiquetas generadas en: {ARCHIVO_SALIDA}")

if __name__ == "__main__":
    generar_pdf()